//ebea theme script for Kplaylist (thanks to Relay theme)
// --------------------------------------------------------------------
//post form

function hiddenField (hiddenaction, hiddenvalue, formsel) {
	var input = document.createElement("input");
	input.setAttribute("type", "hidden");
	input.setAttribute("name", hiddenaction);
	input.setAttribute("value", hiddenvalue);
	document.getElementById(formsel).appendChild(input);
}
function genreok () {
	var genvar = $('genreno').value;
	hiddenField('genreno', genvar, 'misc'); 
	$('misc').submit();
}

//cartmemory script
if (jscookie == 1){

	//JScookie basic functions
	function createCookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
			var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
		document.cookie = name+"="+value+expires+"; path=/";
	}
	
	function readCookie(name) {
		var ca = document.cookie.split(';');
		var nameEQ = name + "=";
		for(var i=0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0)==' ') c = c.substring(1, c.length); //delete spaces
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	function eraseCookie(name)
	{
		createCookie(name, "", -1);
	}
				
	//Functioncartart memory, keeps toggles open when refresh
	if(!readCookie('searchfield')) createCookie('searchfield', 0, 1);
	if(!readCookie('infobox')) createCookie('infobox', 0, 1);
	
	function cartcheck(divid) {	
		var c_searchfield = readCookie('searchfield');
		var c_infobox = readCookie('infobox');
		var c_genrebox = readCookie('genrebox');

		var divElem = document.getElementById(divid);
		
		if (divid == 'searchfield') var onoff = c_searchfield;
		if (divid == 'infobox') var onoff = c_infobox;
		if (divid == 'genrebox') var onoff = c_genrebox;
		
		if (divElem) {
			if (divElem.style.display == "none" && onoff == 1) {
				Element.toggle(divid); 
				Element.toggle(divid+'close');
			}
			if (divElem.style.display == "block" && onoff == 0) {
				Element.toggle(divid); 
				Element.toggle(divid+'close');
			}
		}
	}
				
	function togglememory(memid) {
		var divElement = document.getElementById(memid);		
		if ( divElement.style.display == "none" ) {
			eraseCookie(memid);
			createCookie(memid, 0, 1);
		}
		else {
			eraseCookie(memid);
			createCookie(memid, 1, 1);
		}
	}
}